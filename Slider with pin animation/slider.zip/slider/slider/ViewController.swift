//
//  ViewController.swift
//  slider
//
//  Created by Macbook Pro on 05/01/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageIcon: UIImageView!
    @IBOutlet weak var percentage: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var widthCon: NSLayoutConstraint!
    @IBOutlet weak var leadingCon: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let slidertTrack : CGRect = slider.trackRect(forBounds: slider.bounds)
        let sliderFrm : CGRect = slider.thumbRect(forBounds: slider.bounds, trackRect: slidertTrack, value: slider.value)
         widthCon.constant = sliderFrm.width
        valueChanged(slider)
    }

    
    @IBAction func valueChanged(_ sender: UISlider) {
        let slidertTrack : CGRect = slider.trackRect(forBounds: slider.bounds)
        let sliderFrm : CGRect = slider.thumbRect(forBounds: slider.bounds, trackRect: slidertTrack, value: slider.value)
        
//        percentage.center = CGPoint(x: sliderFrm.origin.x + slider.frame.origin.x + 16, y: slider.frame.origin.y - 30)
        
        // percentage.textAlignment = .center
//        print(sliderFrm.midX)
//        print(sliderFrm.origin.x)
        leadingCon.constant = /*sliderFrm.origin.x + */ sliderFrm.minX - 2
        
//        imageIcon.center = CGPoint(x: sliderFrm.origin.x + slider.frame.origin.x + 16, y: slider.frame.origin.y - 17)
        percentage.text = String(Int(slider.value * 100))
        
    }
    
    
}

